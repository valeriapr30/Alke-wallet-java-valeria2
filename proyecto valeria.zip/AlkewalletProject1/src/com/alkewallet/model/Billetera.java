package com.alkewallet.model; 



public class Billetera implements Operaciones {
    private double saldo;

    public Billetera(double saldoInicial) {
        this.saldo = (saldoInicial >= 0) ? saldoInicial : 0;
    }

    @Override
    public void depositar1(double monto) {
        if (monto > 0) {
            this.saldo += monto;
            System.out.println("Depósito exitoso. Nuevo saldo: $" + this.saldo);
        } else {
            System.out.println("El monto a depositar debe ser positivo.");
        }
    }

    @Override
    public boolean retirar1(double monto) {
        if (monto > 0 && monto <= this.saldo) {
            this.saldo -= monto;
            System.out.println("Retiro exitoso. Saldo restante: $" + this.saldo);
            return true;
        }
        System.out.println("Fondos insuficientes o monto inválido.");
        return false;
    }

    @Override
    public double obtenerSaldo1() {
        return this.saldo;
    }
}