package com.alkewallet.model;

public interface Operaciones {
    void depositar1(double monto);
    boolean retirar1(double monto);
    double obtenerSaldo1();
}