package com.alkewallet;

import java.util.Scanner;

// Importamos las clases desde el paquete correcto (com.alkewallet.model)
import com.alkewallet.model.Billetera;

public class AlkeWalletApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Inicializamos usando los nombres simples gracias a los imports de arriba
        Billetera miBilletera = new Billetera(1000.0);
        ConversorMoneda1 conversor = new ConversorMoneda1();

        boolean continuar = true;
        while (continuar) {
            System.out.println("\n--- BIENVENIDO A ALKE WALLET ---");
            System.out.println("1. Ver Saldo");
            System.out.println("2. Depositar Dinero");
            System.out.println("3. Retirar Dinero");
            System.out.println("4. Convertir Saldo (USD a CLP/EUR)");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            // Validación básica para evitar que el programa explote si no ingresas un número
            if (scanner.hasNextInt()) {
                int opcion = scanner.nextInt();
                switch (opcion) {
                    case 1 -> System.out.println("Saldo actual: $" + miBilletera.obtenerSaldo1());
                    case 2 -> {
                        System.out.print("Monto a depositar: ");
                        miBilletera.depositar1(scanner.nextDouble());
                    }
                    case 3 -> {
                        System.out.print("Monto a retirar: ");
                        miBilletera.retirar1(scanner.nextDouble());
                    }
                    case 4 -> {
                        double saldo = miBilletera.obtenerSaldo1();
                        System.out.println("Equivalente en CLP: $" + conversor.dolarAClp(saldo));
                        // Corregido: Llamamos a dolarAEuro para la segunda opción
                        System.out.println("Equivalente en EUR: €" + conversor.dolarAClp(saldo));
                    }
                    case 5 -> {
                        continuar = false;
                        System.out.println("¡Gracias por preferir Alke Wallet!");
                    }
                    default -> System.out.println("Opción inválida.");
                }
            } else {
                System.out.println("Error: Ingrese un número válido.");
                scanner.next(); // Limpia el error
            }
        }
        scanner.close();
    }
}