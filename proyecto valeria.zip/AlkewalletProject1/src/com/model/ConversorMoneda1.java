package com.model;

public class ConversorMoneda1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public String dolarAClp(double saldo) {
		// TODO Auto-generated method stub
		return null;
	}

	public String dolarAEuro(double saldo) {
		// TODO Auto-generated method stub
		return null;
	}

}
